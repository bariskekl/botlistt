const Discord = require("discord.js");
const ayarlar = require("../ayarlar.json");
let prefix = ayarlar.prefix;

exports.run = async (bot, msg, args) => {
  const seviye = new Discord.MessageEmbed()
    .setAuthor(`BotList Sistemi Komutları`)
    .setTitle(``)
    .setColor("#00ff00")
    .setThumbnail(
      "https://media.discordapp.net/attachments/864903544301289512/874911469437874196/Screenshot_2021-07-22-14-32-16-72.jpg"
    )
    .addField(
      `**__Bot Ekleme__**`,
      `➡️ \`${prefix}bot-ekle\` \n Bot eklersiniz.`,
        true
    )
    .addField(
      `**__İsim Ayarla__**`,
      `➡️ \`${prefix}profil-isim\` \n Profilinize isim ayarlarsınız.`,
         true
    )
  .addField(
      `**__Yaş Ayarla__**`,
      `➡️ \`${prefix}profil-yaş\` \n Profilinize yaş ayarlarsınız.`,
            true
    )
  .addField(
      `**__Soy İsim Ayarla__**`,
      `➡️ \`${prefix}profil-soyisim\` \n Profilinize soy isim ayarlarsınız.`,
      true
    )
  .addField(
      `**__Cinsiyet Ayarla__**`,
      `➡️ \`${prefix}profil-cinsiyet\` \n Profilinize cinsiyet ayarlarsınız.`,
      true
    )
  .addField(
      `**__Bayrak Ayarla__**`,
      `➡️ \`${prefix}profil-bayrak\` \n Profilinize bayrak ayarlarsınız.`,
      true
    )
    .addField(
     "» Linkler",
      ` [Davet Et](https://discord.com/oauth2/authorize?client_id=868057352551694336&scope=bot&permissions=8589934591)` +
        "** | **" +
        `[Destek Sunucusu](https://discord.gg/sYSGctPGua)`
    );
  msg.channel.send(seviye);
};
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: [],
  permLevel: 0,
  kategori: "sunucu"
};
exports.help = {
  name:"botlist",
  description: "Profil sisteminin komutlarını gösterir.",
  usage: "profil-komutlar"
};